1.0.sql
 (empty) OR
 # Dummy SQL file to set schema version to 1.0 so next update will work