DROP TABLE IF EXISTS #__visitors;
DROP TABLE IF EXISTS #__visitors_debug;
DROP TABLE IF EXISTS #__visitors_country;
